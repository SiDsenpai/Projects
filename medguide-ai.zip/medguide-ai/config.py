"""
Central config for MedGuide AI — change model names/paths here only.
Everything is open-source and free: local embeddings (sentence-transformers),
local vector DB (ChromaDB), and a local LLM served by Ollama.
"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data", "raw")
CHROMA_DIR = os.path.join(BASE_DIR, "chroma_db")
COLLECTION_NAME = "medguide_health_topics"

# Open-source, CPU-friendly embedding model (same family used in your earlier RAG project)
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

# Local LLM served by Ollama — fully offline, no API key, no cost.
# On an 8GB M1 Mac, start with a small quantized model:
#   ollama pull llama3.2:3b      (recommended default)
#   ollama pull phi3:mini        (alternative, slightly smaller)
OLLAMA_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama3.2:3b")

RETRIEVAL_K = 4

# Chroma's similarity_search_with_score() returns a *distance* (lower = more
# similar), not a similarity percentage. If even the single closest retrieved
# chunk's distance is above this threshold, the question is treated as "not
# covered by the knowledge base" instead of forcing the LLM to answer from
# loosely-related context (this is what caused odd answers like pulling
# migraine-medicine chunks for a fever question).
#
# Raised from 1.0 -> 1.5 after real testing showed 1.0 was too strict: it was
# rejecting genuinely relevant matches (e.g. a wound/cut question correctly
# retrieved the "Wounds and Injuries" doc, but its distance score was just
# over 1.0, so it got rejected as "not covered" anyway). 1.5 is still a
# placeholder, not a verified-correct number -- run `python rag_chain.py` to
# print real distance scores for an in-corpus vs. out-of-corpus question on
# your machine, and narrow this in further if needed.
RELEVANCE_DISTANCE_THRESHOLD = float(os.environ.get("RELEVANCE_DISTANCE_THRESHOLD", "1.5"))
