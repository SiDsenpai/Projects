# MedGuide AI — Open-Source RAG + Agentic Health-Info Assistant

A fully open-source, fully local, zero-cost GenAI portfolio project: a health-information
chatbot that retrieves grounded answers from a document corpus (RAG), routes messages
through an agentic decision layer (LangGraph), and includes a safety-critical emergency
override, a stubbed appointment "tool call," automated evaluation (RAGAS), and pipeline
monitoring (n8n) — all running on your Mac with no paid API keys.

**Why this project:** it's deliberately built to demonstrate the exact skill cluster
GenAI/AI Engineer job postings ask for in 2026 — RAG, vector search, agentic workflows,
API/microservice design, containerization, evaluation frameworks, and monitoring/reliability
— in one coherent, demoable system instead of five disconnected toy scripts.

**Important disclaimer:** this is a portfolio/demo project, not a real medical product.
The knowledge base in `data/raw/` is sourced from MedlinePlus (a free, public-domain
service of the U.S. National Library of Medicine, NIH) — each file cites its source URL.
It's been condensed and reformatted for this demo, not copied verbatim, and is current as
of the time of writing — always treat the live MedlinePlus pages as the source of truth.
The app itself includes safety disclaimers and an emergency-escalation path, but it is
informational only, not a substitute for professional medical care.

---

## Architecture

```
User question
     │
     ▼
[Streamlit UI] → POST /chat → [FastAPI backend]
                                     │
                                     ▼
                          [LangGraph agent router]
                          ┌──────────┼───────────┐
                          ▼          ▼           ▼
                    "emergency" "appointment" "medical_info"
                    (deterministic   (stubbed       (RAG: ChromaDB
                     safety override) tool call)     retrieval + Ollama
                                                      generation)
```

- **Embeddings:** `sentence-transformers/all-MiniLM-L6-v2` (open-source, CPU-only, ~90MB)
- **Vector DB:** ChromaDB (local, free, file-based)
- **LLM:** served locally by [Ollama](https://ollama.com) — open-source, no API key, runs offline
- **Agent orchestration:** LangGraph (open-source)
- **Backend:** FastAPI
- **Frontend:** Streamlit
- **Evaluation:** RAGAS (open-source), judged by your same local Ollama model
- **Monitoring:** an n8n workflow that health-checks the API and alerts on failure

Nothing in this stack costs money or requires a cloud account.

---

## 1. Prerequisites (Mac M1, 8GB RAM)

1. **Python 3.10+** — check with `python3 --version`.
2. **Ollama** (runs the LLM locally, using Apple Metal acceleration):
   ```bash
   brew install ollama
   ollama serve   # leave running in its own terminal tab
   ```
3. **Pull a small, open-source model.** On 8GB RAM, stick to 3B-class models:
   ```bash
   ollama pull llama3.2:3b      # recommended default — good quality/speed balance
   # or, if llama3.2:3b feels slow/heavy:
   ollama pull phi3:mini        # ~3.8B, also runs fine on 8GB
   ollama pull qwen2.5:3b       # alternative
   ```
   Test it works: `ollama run llama3.2:3b "Say hello in one sentence."`

   If you ever upgrade RAM or want better quality for the RAGAS judge step only, a 7B
   model (`ollama pull qwen2.5:7b`) is noticeably stronger — keep the 3B model for the
   live chat app, swap in the 7B model just for `eval.py` if needed.

4. **(Optional) Docker Desktop for Mac** — only needed if you want to containerize the
   FastAPI backend; not required to run the project locally.

5. **(Optional) n8n** — only needed for the monitoring workflow:
   ```bash
   npx n8n
   ```

---

## 2. Setup

```bash
cd medguide-ai
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

This installs LangChain, LangGraph, ChromaDB, sentence-transformers, FastAPI, Streamlit,
and RAGAS — all open-source, all free.

---

## 3. Build the knowledge base

```bash
python ingest.py
```

This chunks every `.txt` file in `data/raw/`, embeds the chunks with MiniLM, and stores
them in a local ChromaDB at `chroma_db/`. Re-run this any time you add or edit a document.

**To grow the corpus:** add more `.txt` files to `data/raw/` following the same
`TITLE: / SOURCE: / OVERVIEW / SYMPTOMS / CAUSES AND RISK FACTORS / TREATMENT / WHEN TO
SEE A DOCTOR` structure (pulling from MedlinePlus, CDC, or another public-domain/free
source, and citing it in the SOURCE line), then re-run `ingest.py`.

**Licensing note if you pull more MedlinePlus content:** MedlinePlus has two kinds of
pages. Topic-summary pages (URLs like `medlineplus.gov/asthma.html`) are written by
NLM/NIH staff and are public domain — that's what every file in this corpus is sourced
from. Their Medical Encyclopedia / "A.D.A.M." articles (URLs like
`medlineplus.gov/ency/article/...`) are different — those carry a copyright notice that
explicitly prohibits using the content to build embeddings, vector indexes, or any
retrieval-augmented system. Stick to the topic-summary pages only.

**Known limitation, fixed — retrieval relevance threshold:** early testing surfaced a
real RAG failure mode: asking about something outside the corpus (e.g. wound/stitch
aftercare, before the `wounds_and_injuries.txt` file existed) caused the retriever to
return the *closest available* chunks even though they were topically unrelated (e.g.
asthma or depression chunks), and the LLM would then either refuse oddly or stretch
those chunks into a vague non-answer. The fix, in `rag_chain.py` /
`config.RELEVANCE_DISTANCE_THRESHOLD`: if the best retrieved chunk's distance score is
above a tuned cutoff, the app now says it doesn't have reliable info on that topic
instead of forcing an answer from irrelevant context. A second, related fix: the LLM
was occasionally inventing its own fake "Source:" line — the prompt now explicitly
forbids that, since accurate citations are already added deterministically from
document metadata. Both are worth mentioning in interviews as a concrete
debug-and-fix story, not just "I built a RAG app."

---

## 4. Run it

In one terminal (keep `ollama serve` running in another):

```bash
source venv/bin/activate
uvicorn app:app --reload --port 8000
```

In a second terminal:

```bash
source venv/bin/activate
streamlit run streamlit_app.py
```

Open the Streamlit URL it prints (usually `http://localhost:8501`) and start asking
questions, e.g.:
- "What are the symptoms of asthma?"
- "How is GERD treated?"
- "I have chest pain and can't breathe" → should trigger the emergency-escalation path
- "Can I book an appointment?" → should trigger the stubbed appointment-tool path

You can also test the pipeline pieces directly without the UI:
```bash
python rag_chain.py    # quick smoke test of retrieval + generation
python agent.py        # quick smoke test of all three routing paths
```

---

## 5. Run the evaluation

```bash
python eval.py
```

This runs your RAG pipeline against `eval_data/qa_eval_set.json` and scores faithfulness,
answer relevancy, and context precision using RAGAS — judged by your local Ollama model.
Results are saved to `eval_data/eval_results.csv`.

**Known limitation, worth mentioning in interviews:** RAGAS's scoring prompts expect
structured output that small 3B-4B local models sometimes don't format perfectly,
occasionally causing parse errors or noisy scores. If that happens, try a larger model
just for the judge step (`ollama pull qwen2.5:7b`), or fall back to manually reviewing
`eval_results.csv`. Understanding *why* a 3B model struggles with structured-output
evaluation prompts is itself a legitimate, demonstrable piece of ML engineering judgment.

---

## 6. Containerize (optional)

```bash
docker compose up --build
```

This builds and runs the FastAPI backend in a container, calling Ollama on your host
machine via `host.docker.internal`. ChromaDB's data directory is mounted as a volume so
the index persists across container restarts.

---

## 7. Add monitoring (optional)

1. Run n8n locally: `npx n8n`, then open `http://localhost:5678`.
2. Import `monitoring/medguide_health_monitor.json`.
3. Add your own SMTP (or swap the email node for Slack/Discord) credentials — the
   workflow checks `/health` every 15 minutes and alerts if the service is down, plus
   has a separate Error Trigger path if the workflow itself fails. This is the same
   reliability pattern as your existing n8n GitHub-monitor project.

---

## What to say about this project in interviews

- **RAG over a real corpus:** retrieval grounded in ChromaDB + MiniLM embeddings, not
  just calling an LLM raw.
- **Agentic, not single-shot:** LangGraph routes between three distinct paths — and the
  safety-critical path (emergency detection) is deliberately *not* delegated to the LLM,
  which is a real, defensible engineering decision worth explaining.
- **Evaluation-driven:** you have a RAGAS harness and you understand its limitations with
  small local models — that's a more credible signal than a demo with no evaluation at all.
- **Production shape, not just a notebook:** FastAPI service, Dockerized, monitored — the
  same shape as a real backend, even though the scale is small.
- **Zero cost, fully open-source:** every component — embeddings, vector DB, LLM, agent
  framework, evaluation, monitoring — runs locally or self-hosted. You can speak to
  trade-offs between local open-source models and hosted APIs from direct experience.
