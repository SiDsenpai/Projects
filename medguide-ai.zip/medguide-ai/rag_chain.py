"""
Core RAG logic: retrieve relevant chunks from ChromaDB, then generate a
grounded answer using a local, open-source LLM served by Ollama.

No paid APIs anywhere in this file — embeddings and the LLM both run
entirely on your machine.
"""
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_community.llms import Ollama

from config import (
    CHROMA_DIR,
    COLLECTION_NAME,
    EMBEDDING_MODEL,
    OLLAMA_BASE_URL,
    OLLAMA_MODEL,
    RETRIEVAL_K,
    RELEVANCE_DISTANCE_THRESHOLD,
)

SYSTEM_PROMPT = """You are MedGuide AI, an informational health assistant. You are NOT a doctor and you do not diagnose, prescribe, or give personalized medical advice.

Rules:
1. Answer ONLY using the provided context below. If the context does not contain enough information to answer, say so plainly and recommend consulting a healthcare professional — do not guess, and do not fall back on outside/general knowledge.
2. Always include a brief safety note when discussing symptoms or treatment.
3. Do NOT add your own "Source:" line or invent a source name. The application appends accurate source citations separately, taken from document metadata — never fabricate one yourself.
4. Keep answers clear and under ~150 words unless asked for more detail.
"""

PROMPT_TEMPLATE = """{system}

CONTEXT:
{context}

QUESTION:
{question}

ANSWER (grounded only in the context above; do not add a source citation yourself):
"""

_vectordb = None
_llm = None


def _get_vectordb():
    global _vectordb
    if _vectordb is None:
        embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
        _vectordb = Chroma(
            collection_name=COLLECTION_NAME,
            embedding_function=embeddings,
            persist_directory=CHROMA_DIR,
        )
    return _vectordb


def _get_llm():
    global _llm
    if _llm is None:
        _llm = Ollama(base_url=OLLAMA_BASE_URL, model=OLLAMA_MODEL, temperature=0.2)
    return _llm


def retrieve(question: str, k: int = RETRIEVAL_K):
    vectordb = _get_vectordb()
    return vectordb.similarity_search_with_score(question, k=k)


def format_context(results) -> str:
    blocks = []
    for doc, _score in results:
        title = doc.metadata.get("title", "Unknown")
        blocks.append(f"[{title}]\n{doc.page_content}")
    return "\n\n---\n\n".join(blocks)


def _not_covered_response(results=None) -> dict:
    """
    Graceful fallback used when nothing relevant was retrieved (or the best
    match is too dissimilar to trust). This is what fixes the "asked about a
    wound, got asthma/depression chunks back" problem: instead of forcing the
    LLM to generate an answer from irrelevant context, we admit the gap.
    """
    note = ""
    if results:
        closest_titles = sorted({doc.metadata.get("title", "Unknown") for doc, _ in results})
        note = f" The closest topics I do have information on are: {', '.join(closest_titles)}."
    return {
        "answer": (
            "I don't have reliable information on that specific topic in my knowledge base, "
            "so I won't guess." + note + " Please consult a healthcare professional."
        ),
        "sources": [],
        "retrieved_chunks": 0,
    }


def answer_question(question: str, k: int = RETRIEVAL_K) -> dict:
    results = retrieve(question, k=k)

    if not results:
        return _not_covered_response()

    best_distance = min(score for _doc, score in results)
    if best_distance > RELEVANCE_DISTANCE_THRESHOLD:
        # We retrieved *something*, but it's not similar enough to be trustworthy —
        # better to say "I don't know" than to let the LLM stretch unrelated
        # chunks into a confident-sounding wrong answer.
        return _not_covered_response(results)

    context = format_context(results)
    sources = sorted({doc.metadata.get("title", "Unknown") for doc, _ in results})

    prompt = PROMPT_TEMPLATE.format(system=SYSTEM_PROMPT, context=context, question=question)

    llm = _get_llm()
    raw_answer = llm.invoke(prompt)

    return {
        "answer": raw_answer.strip(),
        "sources": sources,
        "retrieved_chunks": len(results),
    }


if __name__ == "__main__":
    # Quick manual smoke test: python rag_chain.py
    # Also prints raw distance scores so you can tune RELEVANCE_DISTANCE_THRESHOLD
    # in config.py — compare scores for an in-corpus vs. out-of-corpus question.
    test_questions = [
        "What are the symptoms of type 2 diabetes?",   # in-corpus
        "How do I fix a flat tire on my bike?",          # clearly out-of-corpus
    ]
    for q in test_questions:
        raw_results = retrieve(q)
        scores = [round(score, 3) for _doc, score in raw_results]
        print("Q:", q)
        print("Distance scores (lower = more relevant):", scores)
        result = answer_question(q)
        print("A:", result["answer"])
        print("Sources:", result["sources"])
        print("---")
