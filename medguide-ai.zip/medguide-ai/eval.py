"""
Evaluation harness using RAGAS (open-source) — scores the RAG pipeline's
retrieval + generation quality on a small Q&A set. The judge model is your
SAME local Ollama model — no OpenAI key, no cost.

Run:
    python eval.py

KNOWN LIMITATION (be upfront about this in interviews — it's a real, useful
insight, not just a caveat): RAGAS's metric prompts expect structured output
that small (3B-4B) local models sometimes fail to format correctly, causing
parse errors or noisy scores. If you hit this:
  - try a slightly larger local judge model just for eval, e.g. `ollama pull
    qwen2.5:7b` (still free/open-source, only used for scoring, not for the
    live app), or
  - fall back to inspecting eval_data/eval_results.csv manually — the
    retrieved contexts + generated answers are saved either way.
"""
import json
from pathlib import Path

from datasets import Dataset
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy, context_precision
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper
from langchain_community.llms import Ollama
from langchain_community.embeddings import HuggingFaceEmbeddings

from config import OLLAMA_BASE_URL, OLLAMA_MODEL, EMBEDDING_MODEL
from rag_chain import retrieve, answer_question

EVAL_FILE = Path(__file__).parent / "eval_data" / "qa_eval_set.json"
RESULTS_FILE = Path(__file__).parent / "eval_data" / "eval_results.csv"


def build_eval_dataset() -> Dataset:
    qa_pairs = json.loads(EVAL_FILE.read_text())

    questions, answers, contexts_list, ground_truths = [], [], [], []

    for item in qa_pairs:
        question = item["question"]
        ground_truth = item["ground_truth"]

        retrieved = retrieve(question)
        contexts = [doc.page_content for doc, _ in retrieved]
        result = answer_question(question)

        questions.append(question)
        answers.append(result["answer"])
        contexts_list.append(contexts)
        ground_truths.append(ground_truth)

        print(f"  - scored retrieval for: {question[:60]}...")

    return Dataset.from_dict(
        {
            "question": questions,
            "answer": answers,
            "contexts": contexts_list,
            "ground_truth": ground_truths,
        }
    )


def main():
    print(f"Loading eval set from {EVAL_FILE} ...")
    print("Running RAG pipeline over each question (this calls your local Ollama model):")
    dataset = build_eval_dataset()

    print("\nScoring with RAGAS (faithfulness, answer_relevancy, context_precision)...")
    judge_llm = LangchainLLMWrapper(Ollama(base_url=OLLAMA_BASE_URL, model=OLLAMA_MODEL))
    judge_embeddings = LangchainEmbeddingsWrapper(HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL))

    result = evaluate(
        dataset,
        metrics=[faithfulness, answer_relevancy, context_precision],
        llm=judge_llm,
        embeddings=judge_embeddings,
    )

    print("\n=== RAGAS Evaluation Results (averaged) ===")
    print(result)

    df = result.to_pandas()
    df.to_csv(RESULTS_FILE, index=False)
    print(f"\nSaved per-question scores to {RESULTS_FILE}")


if __name__ == "__main__":
    main()
