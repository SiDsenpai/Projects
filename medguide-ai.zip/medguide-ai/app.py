"""
FastAPI backend for MedGuide AI.

Run:
    uvicorn app:app --reload --port 8000

Endpoints:
    GET  /health   - liveness check (used by the n8n monitoring workflow)
    POST /chat      - { "question": "..." } -> grounded answer + sources
"""
from typing import List

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from agent import run_agent

app = FastAPI(
    title="MedGuide AI",
    description="Open-source RAG + agentic health-information assistant (portfolio demo).",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    question: str


class ChatResponse(BaseModel):
    answer: str
    sources: List[str]
    escalated: bool


@app.get("/health")
def health():
    return {"status": "ok", "service": "medguide-ai"}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    result = run_agent(req.question)
    return ChatResponse(
        answer=result["answer"],
        sources=result["sources"],
        escalated=result["escalated"],
    )
