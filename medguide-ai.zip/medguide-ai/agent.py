"""
Agentic routing layer for MedGuide AI — built with LangGraph (open-source).

This is what makes the project "agentic" rather than a single-shot RAG demo:
every incoming message is routed by a small state graph to one of three paths
before a response is composed:

  1. emergency     - deterministic, keyword-based safety override (never relies
                      on the LLM for this — a probabilistic model should not be
                      the only thing standing between a user and emergency care)
  2. appointment    - a stubbed "tool call" showing where a real scheduling/EHR
                      API would plug in (clearly labeled as a demo stub)
  3. medical_info   - the default path: grounded RAG retrieval + generation

This mirrors how production conversational-AI/voice-agent systems (e.g. a
clinic triage bot) are actually structured: safety-critical routing first,
tool-use second, open-ended generation last.
"""
import re
from typing import List, TypedDict

from langgraph.graph import StateGraph, END

from rag_chain import answer_question

EMERGENCY_PATTERNS = [
    r"can'?t breathe",
    r"chest pain",
    r"severe bleeding",
    r"unconscious",
    r"suicidal",
    r"want to (die|kill myself)",
    r"overdose",
    r"stroke symptoms",
    r"not breathing",
    r"heart attack",
]

APPOINTMENT_PATTERNS = [
    r"book.*appointment",
    r"schedule.*(appointment|visit)",
    r"see a doctor",
    r"speak (to|with) a (doctor|nurse)",
    r"find a (doctor|clinic)",
]


class AgentState(TypedDict):
    question: str
    intent: str
    answer: str
    sources: List[str]
    escalated: bool


def classify_intent(state: AgentState) -> AgentState:
    q = state["question"].lower()
    if any(re.search(p, q) for p in EMERGENCY_PATTERNS):
        state["intent"] = "emergency"
    elif any(re.search(p, q) for p in APPOINTMENT_PATTERNS):
        state["intent"] = "appointment"
    else:
        state["intent"] = "medical_info"
    return state


def handle_emergency(state: AgentState) -> AgentState:
    state["answer"] = (
        "This sounds like it could be a medical emergency. Please call your local "
        "emergency number (e.g. 112 / 911 / 108) or go to the nearest emergency room "
        "right away. I'm an informational assistant only and can't help with emergencies."
    )
    state["sources"] = []
    state["escalated"] = True
    return state


def handle_appointment(state: AgentState) -> AgentState:
    # Simulated tool call. In a real deployment this node would call the
    # clinic's scheduling/EHR API. Stubbed here so the demo has zero
    # external dependencies and zero cost.
    state["answer"] = (
        "I've logged your appointment request (demo mode — no real booking "
        "system is connected here). In production, this step would call the "
        "clinic's scheduling API and return a confirmed time. For now, please "
        "contact your provider directly."
    )
    state["sources"] = []
    state["escalated"] = False
    return state


def handle_medical_info(state: AgentState) -> AgentState:
    result = answer_question(state["question"])
    state["answer"] = result["answer"]
    state["sources"] = result["sources"]
    state["escalated"] = False
    return state


def _route(state: AgentState) -> str:
    return state["intent"]


def build_agent():
    graph = StateGraph(AgentState)
    graph.add_node("classify_intent", classify_intent)
    graph.add_node("emergency", handle_emergency)
    graph.add_node("appointment", handle_appointment)
    graph.add_node("medical_info", handle_medical_info)

    graph.set_entry_point("classify_intent")
    graph.add_conditional_edges(
        "classify_intent",
        _route,
        {
            "emergency": "emergency",
            "appointment": "appointment",
            "medical_info": "medical_info",
        },
    )
    graph.add_edge("emergency", END)
    graph.add_edge("appointment", END)
    graph.add_edge("medical_info", END)

    return graph.compile()


_agent = None


def get_agent():
    global _agent
    if _agent is None:
        _agent = build_agent()
    return _agent


def run_agent(question: str) -> dict:
    agent = get_agent()
    result = agent.invoke(
        {"question": question, "intent": "", "answer": "", "sources": [], "escalated": False}
    )
    return result


if __name__ == "__main__":
    # Quick manual smoke tests: python agent.py
    for q in [
        "What are the symptoms of asthma?",
        "I have chest pain and can't breathe",
        "Can I book an appointment for next week?",
    ]:
        r = run_agent(q)
        print("Q:", q)
        print("Intent path -> answer:", r["answer"][:200])
        print("Escalated:", r["escalated"])
        print("---")
