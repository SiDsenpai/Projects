"""
Streamlit chat UI for MedGuide AI.

Run (with app.py already running in another terminal on port 8000):
    streamlit run streamlit_app.py
"""
import requests
import streamlit as st

API_URL = "http://localhost:8000/chat"

st.set_page_config(page_title="MedGuide AI", page_icon="🩺")
st.title("🩺 MedGuide AI")
st.caption(
    "Open-source RAG + agentic health-info assistant (portfolio demo). "
    "Informational only — not a substitute for professional medical advice. "
    "Runs entirely on free, open-source tools: Ollama + LangChain + LangGraph + ChromaDB."
)

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

if prompt := st.chat_input("Ask a health question, e.g. 'What are the symptoms of asthma?'"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            try:
                resp = requests.post(API_URL, json={"question": prompt}, timeout=120)
                resp.raise_for_status()
                data = resp.json()
                answer = data["answer"]
                if data.get("sources"):
                    answer += "\n\n*Sources: " + ", ".join(data["sources"]) + "*"
                if data.get("escalated"):
                    st.warning("This message was flagged as a possible emergency.")
            except Exception as e:
                answer = f"Error contacting backend ({API_URL}): {e}"
            st.markdown(answer)
    st.session_state.messages.append({"role": "assistant", "content": answer})
