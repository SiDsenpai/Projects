"""
Ingestion pipeline: load health-topic .txt files -> chunk -> embed -> store in ChromaDB.

Run once (and again any time you add/edit files in data/raw/):
    python ingest.py
"""
import re
from pathlib import Path

from langchain.schema import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma

from config import DATA_DIR, CHROMA_DIR, EMBEDDING_MODEL, COLLECTION_NAME


def parse_metadata(text: str, fallback_title: str):
    title_match = re.search(r"TITLE:\s*(.+)", text)
    source_match = re.search(r"SOURCE:\s*(.+)", text)
    title = title_match.group(1).strip() if title_match else fallback_title
    source = source_match.group(1).strip() if source_match else "unknown"
    return title, source


def load_documents():
    docs = []
    for path in sorted(Path(DATA_DIR).glob("*.txt")):
        raw = path.read_text(encoding="utf-8")
        title, source = parse_metadata(raw, path.stem)
        docs.append({"text": raw, "title": title, "source": source, "filename": path.name})
    return docs


def build_index():
    raw_docs = load_documents()
    if not raw_docs:
        raise SystemExit(f"No .txt files found in {DATA_DIR}. Add some health-topic files first.")
    print(f"Loaded {len(raw_docs)} source documents from {DATA_DIR}")

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=700,
        chunk_overlap=100,
        separators=["\n\n", "\n", ". ", " "],
    )

    lc_docs = []
    for d in raw_docs:
        chunks = splitter.split_text(d["text"])
        for i, chunk in enumerate(chunks):
            lc_docs.append(
                Document(
                    page_content=chunk,
                    metadata={
                        "title": d["title"],
                        "source": d["source"],
                        "filename": d["filename"],
                        "chunk": i,
                    },
                )
            )
    print(f"Split into {len(lc_docs)} chunks")

    print(f"Loading embedding model '{EMBEDDING_MODEL}' (first run downloads ~90MB, then it's cached)...")
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)

    print("Building ChromaDB index (this may take a minute)...")
    vectordb = Chroma.from_documents(
        documents=lc_docs,
        embedding=embeddings,
        collection_name=COLLECTION_NAME,
        persist_directory=CHROMA_DIR,
    )
    vectordb.persist()
    print(f"Done. Indexed {len(lc_docs)} chunks into ChromaDB at: {CHROMA_DIR}")


if __name__ == "__main__":
    build_index()
